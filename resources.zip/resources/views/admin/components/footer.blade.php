<footer class="main-footer">
    <strong>
        {{ $settings['copyright'] ?? '' }} {{ __('Created by') }} <a href="https://codeshaper.net/" target="_blank"><i class="fas fa-heart red"></i> CODESHAPER</a>
    </strong>
</footer>
