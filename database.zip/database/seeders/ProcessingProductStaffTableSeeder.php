<?php

namespace Database\Seeders;

use DB;
use Illuminate\Database\Seeder;

class ProcessingProductStaffTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('processing_product_staff')->delete();

        DB::table('processing_product_staff')->insert(array(
            0 =>
            array(
                'processing_product_id' => 1,
                'staff_id' => 1,
                'processing_step_id' => 1,
            ),
            1 =>
            array(
                'processing_product_id' => 1,
                'staff_id' => 1,
                'processing_step_id' => 2,
            ),
            3 =>
            array(
                'processing_product_id' => 1,
                'staff_id' => 2,
                'processing_step_id' => 2,
            ),
            4 =>
            array(
                'processing_product_id' => 1,
                'staff_id' => 2,
                'processing_step_id' => 3,
            ),
            5 =>
            array(
                'processing_product_id' => 2,
                'staff_id' => 2,
                'processing_step_id' => 1,
            ),
            6 =>
            array(
                'processing_product_id' => 2,
                'staff_id' => 2,
                'processing_step_id' => 2,
            ),
            7 =>
            array(
                'processing_product_id' => 2,
                'staff_id' => 2,
                'processing_step_id' => 3,
            ),
        ));
    }
}