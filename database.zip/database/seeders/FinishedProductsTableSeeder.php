<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class FinishedProductsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('finished_products')->delete();
        DB::table('finished_products')->insert(array(
            0 =>
            array(
                'id' => 1,
                'porcessing_pro_id' => 1,
                'sub_cat_id' => 1,
                'finished_code' => 1,
                'slug' => 1,
                'sizes' => 'XXL, XL, L, M, S',
                'rejected_quantities' => ', , , , ',
                'quantities' => '10, 10, 10, 10, 10',
                'finished_date' => Carbon::now()->addDays(6)->format('Y-m-d'),
                'finished_image' => 'This is the finished product',
                'note' => '1',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            1 =>
            array(
                'id' => 2,
                'porcessing_pro_id' => 2,
                'sub_cat_id' => 3,
                'finished_code' => 2,
                'slug' => 2,
                'sizes' => 'XXL, XL, L, M, S',
                'rejected_quantities' => ', , , , ',
                'quantities' => '20, 20, 20, 20, 20',
                'finished_date' => Carbon::now()->addDays(6)->format('Y-m-d'),
                'finished_image' => 'This is the finished product',
                'note' => '1',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            )
        ));
    }
}