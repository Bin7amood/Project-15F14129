<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class StaffTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('staff')->delete();

        DB::table('staff')->insert(array(
            0 =>
            array(
                'id' => 1,
                'name' => 'Mari Johns',
                'phone_number' => '0170000000',
                'email' => 'mari_johns@codeshaper.tech',
                'department' => 'Embroidery',
                'designation' => 'Designer',
                'profile_picture' => 'default.png',
                'address' => 'Dhaka, Bangladesh',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            1 =>
            array(
                'id' => 2,
                'name' => 'Whilemina Watts',
                'phone_number' => '0180000000',
                'email' => 'whilemina_watts@codeshaper.tech',
                'department' => 'Processing',
                'designation' => 'Administrator',
                'profile_picture' => 'default.png',
                'address' => 'Dhaka, Bangladesh',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
        ));
    }
}