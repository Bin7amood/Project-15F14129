<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class PurchaseProductsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {

        DB::table('purchase_products')->delete();

        DB::table('purchase_products')->insert(array(
            0 =>
            array(
                'id' => 1,
                'purchase_id' => 1,
                'product_name' => 'Raw Material 1',
                'unit' => 'KG',
                'quantity' => 100.0,
                'unit_price' => 20.0,
                'discount' => NULL,
                'total' => 2000.0,
                'used_quantity' => NULL,
                'damage_quantity' => NULL,
                'return_quantity' => 20,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),

            ),
            1 =>
            array(
                'id' => 2,
                'purchase_id' => 1,
                'product_name' => 'Raw Material 2',
                'unit' => 'KG',
                'quantity' => 150.0,
                'unit_price' => 25.0,
                'discount' => NULL,
                'total' => 3750,
                'used_quantity' => NULL,
                'damage_quantity' => NULL,
                'return_quantity' => 20,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            2 =>
            array(
                'id' => 3,
                'purchase_id' => 1,
                'product_name' => 'Raw Material 3',
                'unit' => 'KG',
                'quantity' => 200.0,
                'unit_price' => 20.0,
                'discount' => NULL,
                'total' => 4000,
                'used_quantity' => NULL,
                'damage_quantity' => NULL,
                'return_quantity' => 20,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            3 =>
            array(
                'id' => 4,
                'purchase_id' => 2,
                'product_name' => 'Raw Material 4',
                'unit' => 'KG',
                'quantity' => 100.0,
                'unit_price' => 20.0,
                'discount' => NULL,
                'total' => 2000.0,
                'used_quantity' => NULL,
                'damage_quantity' => 5,
                'return_quantity' => NULL,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),

            ),
            4 =>
            array(
                'id' => 5,
                'purchase_id' => 2,
                'product_name' => 'Raw Material 5',
                'unit' => 'KG',
                'quantity' => 150.0,
                'unit_price' => 25.0,
                'discount' => NULL,
                'total' => 3750,
                'used_quantity' => NULL,
                'damage_quantity' => 5,
                'return_quantity' => NULL,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            5 =>
            array(
                'id' => 6,
                'purchase_id' => 2,
                'product_name' => 'Raw Material 6',
                'unit' => 'KG',
                'quantity' => 200.0,
                'unit_price' => 20.0,
                'discount' => NULL,
                'total' => 4000,
                'used_quantity' => NULL,
                'damage_quantity' => 5,
                'return_quantity' => NULL,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            6 =>
            array(
                'id' => 7,
                'purchase_id' => 3,
                'product_name' => 'Raw Material 7',
                'unit' => 'KG',
                'quantity' => 100.0,
                'unit_price' => 20.0,
                'discount' => NULL,
                'total' => 2000.0,
                'used_quantity' => NULL,
                'damage_quantity' => NULL,
                'return_quantity' => NULL,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),

            ),
            7 =>
            array(
                'id' => 8,
                'purchase_id' => 3,
                'product_name' => 'Raw Material 8',
                'unit' => 'KG',
                'quantity' => 150.0,
                'unit_price' => 25.0,
                'discount' => NULL,
                'total' => 3750,
                'used_quantity' => NULL,
                'damage_quantity' => NULL,
                'return_quantity' => NULL,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            8 =>
            array(
                'id' => 9,
                'purchase_id' => 3,
                'product_name' => 'Raw Material 9',
                'unit' => 'KG',
                'quantity' => 200.0,
                'unit_price' => 20.0,
                'discount' => NULL,
                'total' => 4000,
                'used_quantity' => NULL,
                'damage_quantity' => NULL,
                'return_quantity' => NULL,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            )
        ));
    }
}