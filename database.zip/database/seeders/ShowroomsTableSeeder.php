<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class ShowroomsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('showrooms')->delete();
        DB::table('showrooms')->insert(array(
            0 =>
            array(
                'id' => 1,
                'code' => 'PS-0001',
                'name' => 'Malaysia Showroom',
                'email' => 'malaysia@codeshaper.tech',
                'phone_number' => '017000000',
                'manager' => 'Jhon Doe',
                'slug' => 'malaysia-showroom',
                'address' => 'Malaysia',
                'note' => 'This is a note!',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            1 =>
            array(
                'id' => 2,
                'code' => 'PS-0002',
                'name' => 'Canada Showroom',
                'email' => 'canada@codeshaper.tech',
                'phone_number' => '017000000',
                'manager' => 'Jhon Doe',
                'slug' => 'canada-showroom',
                'address' => 'Canada',
                'note' => 'This is a note!',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            2 =>
            array(
                'id' => 3,
                'code' => 'PS-0003',
                'name' => 'UK Showroom',
                'email' => 'uk@codeshaper.tech',
                'phone_number' => '017000000',
                'manager' => 'Jhon Doe',
                'slug' => 'uk-showroom',
                'address' => 'UK',
                'note' => 'This is a note!',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
        ));
    }
}