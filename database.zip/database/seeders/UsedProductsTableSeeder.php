<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class UsedProductsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('used_products')->delete();
        DB::table('used_products')->insert(array(
            0 =>
            array(
                'id' => 1,
                'finished_id' => 1,
                'purchase_pro_id' => 1,
                'used_quantity' => 60,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            1 =>
            array(
                'id' => 2,
                'finished_id' => 1,
                'purchase_pro_id' => 2,
                'used_quantity' => 80,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            2 =>
            array(
                'id' => 3,
                'finished_id' => 1,
                'purchase_pro_id' => 3,
                'used_quantity' => 120,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            3 =>
            array(
                'id' => 4,
                'finished_id' => 2,
                'purchase_pro_id' => 4,
                'used_quantity' => 90,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            4 =>
            array(
                'id' => 5,
                'finished_id' => 2,
                'purchase_pro_id' => 5,
                'used_quantity' => 120,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            5 =>
            array(
                'id' => 6,
                'finished_id' => 2,
                'purchase_pro_id' => 6,
                'used_quantity' => 170,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
        ));
    }
}