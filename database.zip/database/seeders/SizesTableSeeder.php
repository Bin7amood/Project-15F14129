<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SizesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('sizes')->delete();
        DB::table('sizes')->insert(array(
            0 =>
            array(
                'id' => 1,
                'code' => 'XXL',
                'name' => 'Double Extra Large',
                'slug' => 'double-extra-large',
                'note' => 'Double Extra Large',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            1 =>
            array(
                'id' => 2,
                'code' => 'XL',
                'name' => 'Extra Large',
                'slug' => 'extra-large',
                'note' => 'Extra Large',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            2 =>
            array(
                'id' => 3,
                'code' => 'L',
                'name' => 'Large',
                'slug' => 'large',
                'note' => 'Large',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            3 =>
            array(
                'id' => 4,
                'code' => 'M',
                'name' => 'Medium',
                'slug' => 'medium',
                'note' => 'Medium',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            4 =>
            array(
                'id' => 5,
                'code' => 'S',
                'name' => 'Small',
                'slug' => 'small',
                'note' => 'Small',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
        ));
    }
}