<?php

namespace Database\Seeders;

use App\Models\GeneralSetting;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // seed basic data to tables
        $this->call(GeneralSettingsTableSeeder::class);
        $this->call(UsersTableSeeder::class);
    }
}