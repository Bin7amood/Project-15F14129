<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class SuppliersTableSeeder extends Seeder
{
    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('suppliers')->delete();
        DB::table('suppliers')->insert(array(
            0 =>
            array(
                'id' => 1,
                'name' => 'Carla Bender',
                'email' => 'carla_bender@codeshaper.tech',
                'phone_number' => '017000000',
                'designation' => 'Sales Man',
                'company_name' => 'Codeshaper',
                'profile_picture' => 'default.png',
                'address' => 'Dhaka, Bangladesh',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),

            ),
            1 =>
            array(
                'id' => 2,
                'name' => 'Amir Vega',
                'email' => 'amir_vega@codeshaper.tech',
                'phone_number' => '018000000',
                'designation' => 'Marketing Manager',
                'company_name' => 'Codeshaper',
                'profile_picture' => 'default.png',
                'address' => 'Dhaka, Bangladesh',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),

        ));
    }
}