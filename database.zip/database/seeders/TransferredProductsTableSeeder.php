<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class TransferredProductsTableSeeder extends Seeder
{
    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('transferred_products')->delete();
        DB::table('transferred_products')->insert(array(
            0 =>
            array(
                'id' => 1,
                'finished_id' => 1,
                'showroom_id' => 3,
                'transferred_code' => 1,
                'slug' => '1',
                'transferred_date' => Carbon::now()->addDays(7)->format('Y-m-d'),
                'cartoon_number' => 'CAR-0001',
                'transferred_quantities' => '5, 5, 5, 5, 5',
                'transferred_image' => '',
                'note' => 'This is transferred note!',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            1 =>
            array(
                'id' => 2,
                'finished_id' => 1,
                'showroom_id' => 3,
                'transferred_code' => 2,
                'slug' => '2',
                'transferred_date' => Carbon::now()->addDays(7)->format('Y-m-d'),
                'cartoon_number' => 'CAR-0002',
                'transferred_quantities' => '5, 5, 5, 5, 5',
                'transferred_image' => '',
                'note' => 'This is transferred note!',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
        ));
    }
}