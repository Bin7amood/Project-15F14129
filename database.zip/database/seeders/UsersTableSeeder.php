<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->delete();
        DB::table('users')->insert(array(
            0 =>
            array(
                'id' => 1,
                'name' => 'Admin',
                'email' => 'superadmin@productify.com',
                'email_verified_at' => NULL,
                'password' => '$2y$10$6L2NSBog3vBgN5zozyuMieMp6ofihcf8bgRRQXUT6HEYsSkCogOqG', //productify2022
                'remember_token' => 'M4338g5ryyUVYEevD1Poiu8gGnBGIO38RA9OwC8lAG0tWkg2wrEciAnIwj3w',
                'profile_picture' => 'default.png',
                'role' => 1,
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
        ));
    }
}