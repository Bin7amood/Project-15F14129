<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class ExpensesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('expenses')->delete();

        DB::table('expenses')->insert(array(
            0 =>
            array(
                'id' => 1,
                'expense_reason' => 'Office Rent',
                'slug' => 'office-rent',
                'amount' => 10000,
                'exp_cat_id' => 2,
                'expense_date' => Carbon::now()->format('Y-m-d'),
                'expense_image' => null,
                'note' => 'Office Rent',
                'status' => 1,
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            1 =>
            array(
                'id' => 2,
                'expense_reason' => 'Sticky Notes',
                'slug' => 'sticky-notes',
                'amount' => 100.0,
                'exp_cat_id' => 1,
                'expense_date' => Carbon::now()->format('Y-m-d'),
                'expense_image' => null,
                'note' => 'Sticky notes',
                'status' => 1,
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
        ));
    }
}