<?php

namespace Database\Seeders;

use App\Models\GeneralSetting;
use Illuminate\Database\Seeder;

class DemoDatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // seed basic data to tables
        $this->call(GeneralSettingsTableSeeder::class);
        $this->call(UsersTableSeeder::class);
        $this->call(UnitsTableSeeder::class);
        $this->call(SizesTableSeeder::class);
        $this->call(PaymentMethodsTableSeeder::class);
        $this->call(ProcessingStepsTableSeeder::class);
        $this->call(ShowroomsTableSeeder::class);
        $this->call(CategoriesTableSeeder::class);
        $this->call(SubCategoriesTableSeeder::class);
        $this->call(SuppliersTableSeeder::class);
        $this->call(StaffTableSeeder::class);
        $this->call(PurchasesTableSeeder::class);
        $this->call(PurchaseProductsTableSeeder::class);
        $this->call(ProcessingProductsTableSeeder::class);
        $this->call(FinishedProductsTableSeeder::class);
        $this->call(TransferredProductsTableSeeder::class);
        $this->call(ProcessingProductStaffTableSeeder::class);
        $this->call(ExpenseCategoriesTableSeeder::class);
        $this->call(ExpensesTableSeeder::class);
        $this->call(PurchaseReturnsTableSeeder::class);
        $this->call(PurchaseDamagesTableSeeder::class);
        $this->call(UsedProductsTableSeeder::class);
    }
}