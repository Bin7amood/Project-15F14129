<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class PurchasesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('purchases')->delete();
        DB::table('purchases')->insert(array(
            0 =>
            array(
                'id' => 1,
                'supplier_id' => 1,
                'purchase_code' => '1',
                'discount' => 0.0,
                'trasnport' => NULL,
                'sub_total' => 9750,
                'total' => 9750,
                'total_due' => 0,
                'total_paid' => 9750,
                'payment_type' => 'Bank Transfer',
                'note' => '',
                'purchase_date' => Carbon::now()->format('Y-m-d'),
                'purchase_image' => '',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            1 =>
            array(
                'id' => 2,
                'supplier_id' => 2,
                'purchase_code' => '2',
                'discount' => 0.0,
                'trasnport' => NULL,
                'sub_total' => 9750,
                'total' => 9750,
                'total_due' => 9750,
                'total_paid' => 0,
                'payment_type' => 'Bank Transfer',
                'note' => '',
                'purchase_date' => Carbon::now()->format('Y-m-d'),
                'purchase_image' => '',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            2 =>
            array(
                'id' => 3,
                'supplier_id' => 1,
                'purchase_code' => '3',
                'discount' => 0.0,
                'trasnport' => NULL,
                'sub_total' => 9750,
                'total' => 9750,
                'total_due' => 9750,
                'total_paid' => 0,
                'payment_type' => 'Bank Transfer',
                'note' => '',
                'purchase_date' => Carbon::now()->format('Y-m-d'),
                'purchase_image' => '',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            )
        ));
    }
}