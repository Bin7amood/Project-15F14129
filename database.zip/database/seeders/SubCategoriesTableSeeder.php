<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class SubCategoriesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('sub_categories')->delete();

        DB::table('sub_categories')->insert(array(
            0 =>
            array(
                'id' => 1,
                'category_id' => 1,
                'name' => 'Text',
                'slug' => 'text',
                'note' => 'Text T-shirts',
                'sizes' => 'XXL, XL, L, M, S',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            1 =>
            array(
                'id' => 2,
                'category_id' => 1,
                'name' => 'Design',
                'slug' => 'design',
                'note' => 'Design T-shirts',
                'sizes' => 'XXL, XL, L, M, S',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            2 =>
            array(
                'id' => 3,
                'category_id' => 2,
                'name' => 'Formal',
                'slug' => 'formal',
                'note' => 'Formal Shirts',
                'sizes' => 'XXL, XL, L, M, S',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            3 =>
            array(
                'id' => 4,
                'category_id' => 2,
                'name' => 'Casual',
                'slug' => 'casual',
                'note' => 'Casual Shirts',
                'sizes' => 'XXL, XL, L, M, S',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            )

        ));
    }
}