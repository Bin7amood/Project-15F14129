<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class ExpenseCategoriesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('expense_categories')->delete();
        DB::table('expense_categories')->insert(array(
            0 =>
            array(

                'id' => 1,
                'name' => 'Stationary',
                'note' => 'Stationary',
                'slug' => 'stationary',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            3 =>
            array(
                'id' => 2,
                'name' => 'Rent',
                'note' => 'rent',
                'slug' => 'rent',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
        ));
    }
}