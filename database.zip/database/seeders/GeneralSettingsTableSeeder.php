<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class GeneralSettingsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('general_settings')->delete();
        DB::table('general_settings')->insert(array(
            0 =>
            array(
                'id' => 1,
                'key' => 'company_name',
                'display_name' => 'Company Name',
                'value' => 'Productify',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),

            ),
            1 =>
            array(
                'id' => 2,
                'key' => 'compnay_tagline',
                'display_name' => 'Company Tagline',
                'value' => 'Production Management System',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            2 =>
            array(
                'id' => 3,
                'key' => 'email_address',
                'display_name' => 'Email Address',
                'value' => 'support@codeshaper.net',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            3 =>
            array(
                'id' => 4,
                'key' => 'phone_number',
                'display_name' => 'Phone Number',
                'value' => '01700000000',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            4 =>
            array(
                'id' => 5,
                'key' => 'address',
                'display_name' => 'Address',
                'value' => 'Dhaka, Bangladesh',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            5 =>
            array(
                'id' => 6,
                'key' => 'currency_name',
                'display_name' => 'Currency Name',
                'value' => 'USD',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            6 =>
            array(
                'id' => 7,
                'key' => 'currency_symbol',
                'display_name' => 'Currency Symbol',
                'value' => '$',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            7 =>
            array(
                'id' => 8,
                'key' => 'currency_position',
                'display_name' => 'Currency Position',
                'value' => 'left',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            8 =>
            array(
                'id' => 9,
                'key' => 'timezone',
                'display_name' => 'Timezone',
                'value' => 'Asia/Dhaka',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            9 =>
            array(
                'id' => 10,
                'key' => 'purchase_code_prefix',
                'display_name' => 'Purchase Code Prefix',
                'value' => 'PP-',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            10 =>
            array(
                'id' => 11,
                'key' => 'processing_code_prefix',
                'display_name' => 'Processing Code Prefix',
                'value' => 'PPRO-',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            11 =>
            array(
                'id' => 12,
                'key' => 'finished_code_prefix',
                'display_name' => 'Finished Code Prefix',
                'value' => 'PFIN-',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            12 =>
            array(
                'id' => 13,
                'key' => 'transferred_code_prefix',
                'display_name' => 'Transferred Code Prefix',
                'value' => 'PTRA-',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            13 =>
            array(
                'id' => 14,
                'key' => 'starting_purchase_code',
                'display_name' => 'Starting Purchase Code',
                'value' => 'PSPC-',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            14 =>
            array(

                'id' => 15,
                'key' => 'logo',
                'display_name' => 'Logo',
                'value' => 'logo-black.svg',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            15 =>
            array(
                'id' => 16,
                'key' => 'dark_logo',
                'display_name' => 'Dark Logo',
                'value' => 'white-logo.png',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            16 =>
            array(
                'id' => 17,
                'key' => 'small_logo',
                'display_name' => 'Small Logo',
                'value' => 'small-dark-logo.png',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            17 =>
            array(
                'id' => 18,
                'key' => 'small_dark_logo',
                'display_name' => 'Small Dark Logo',
                'value' => 'white-small-logo.png',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            18 =>
            array(
                'id' => 19,
                'key' => 'favicon',
                'display_name' => 'Favicon',
                'value' => 'favicon.png',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            19 =>
            array(
                'id' => 20,
                'key' => 'copyright',
                'display_name' => 'Copyright',
                'value' => 'Codeshaper',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
        ));
    }
}