<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class UnitsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('units')->delete();
        DB::table('units')->insert(array(
            0 =>
            array(
                'id' => 12,
                'code' => 'pcs',
                'name' => 'Pcs',
                'note' => 'Pieces',
                'slug' => 'pcs',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
            1 =>
            array(

                'id' => 2,
                'code' => 'Btls',
                'name' => 'Bottles',
                'note' => 'Test note',
                'slug' => 'kilogram',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
        ));
    }
}