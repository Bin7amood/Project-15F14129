<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class PurchaseReturnsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        DB::table('purchase_returns')->delete();

        DB::table('purchase_returns')->insert(array(
            0 =>
            array(
                'id' => 1,
                'purchase_id' => 1,
                'return_reason' => 'Product Expired',
                'slug' => 'product-expired',
                'note' => 'Product Expired',
                'refund_amount' => 1300.00,
                'return_date' => Carbon::now()->format('Y-m-d'),
                'return_image' => '',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),

        ));
    }
}