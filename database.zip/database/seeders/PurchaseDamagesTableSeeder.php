<?php

namespace Database\Seeders;

use DB;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class PurchaseDamagesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {

        DB::table('purchase_damages')->delete();
        DB::table('purchase_damages')->insert(array(
            0 =>
            array(
                'id' => 1,
                'purchase_id' => 2,
                'damage_reason' => 'Product Damage',
                'note' => 'Product Damage',
                'slug' => 'product-damage',
                'damage_date' => Carbon::now()->format('Y-m-d'),
                'damage_image' => '',
                'status' => 1,
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ),
        ));
    }
}